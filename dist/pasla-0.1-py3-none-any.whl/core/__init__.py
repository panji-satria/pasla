# core/__init__.py
#hello_pasla